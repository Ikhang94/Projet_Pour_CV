//
// Created by caoth on 07/02/2023.
//

#ifndef PROJET_QCM_SERVEUR_H
#define PROJET_QCM_SERVEUR_H
#include <winsock2.h>
#include <iostream>
#include <fstream>
#define VERSION 0x0101

class Serveur
{
private :
    SOCKET			prise;
    SOCKADDR_IN		connection;

public :
    Serveur(u_short);
    ~Serveur();
    int recoit(int, char FAR * const) const;
    unsigned long recoitFic(char FAR *const) const;
};


#endif //PROJET_QCM_SERVEUR_H
